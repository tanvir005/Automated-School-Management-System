-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2021 at 07:14 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `accademicfees`
--

CREATE TABLE `accademicfees` (
  `Student_Id` int(5) NOT NULL,
  `Class` int(2) NOT NULL,
  `January` int(5) DEFAULT NULL,
  `February` int(5) DEFAULT NULL,
  `March` int(5) DEFAULT NULL,
  `April` int(5) DEFAULT NULL,
  `June` int(5) DEFAULT NULL,
  `July` int(5) DEFAULT NULL,
  `August` int(5) DEFAULT NULL,
  `September` int(5) DEFAULT NULL,
  `Octobor` int(5) DEFAULT NULL,
  `November` int(5) DEFAULT NULL,
  `December` int(5) DEFAULT NULL,
  `firstXm` int(5) DEFAULT NULL,
  `secondxm` int(5) DEFAULT NULL,
  `thirdxm` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accademicfees`
--

INSERT INTO `accademicfees` (`Student_Id`, `Class`, `January`, `February`, `March`, `April`, `June`, `July`, `August`, `September`, `Octobor`, `November`, `December`, `firstXm`, `secondxm`, `thirdxm`) VALUES
(1, 3, 3000, 3000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(90, 7, NULL, NULL, NULL, NULL, 5000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accountent`
--

CREATE TABLE `accountent` (
  `ac_id` int(11) NOT NULL,
  `username` varchar(10) DEFAULT NULL,
  `full_name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `gender` varchar(5) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `Sucurity_A` varchar(20) DEFAULT NULL,
  `sucurity_q` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accountent`
--

INSERT INTO `accountent` (`ac_id`, `username`, `full_name`, `password`, `gender`, `email`, `mobile`, `Sucurity_A`, `sucurity_q`) VALUES
(1, 'staff', 'staff', 'staff', '', 'staff', 'staff', 'staff', 'staff'),
(2, 'staff1', 'staff1', 'staff1', '', '', '', 'staff1', 'staff1');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `inbuildsecurity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`inbuildsecurity`) VALUES
(5507);

-- --------------------------------------------------------

--
-- Table structure for table `adminstrator`
--

CREATE TABLE `adminstrator` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(10) DEFAULT NULL,
  `full_name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `gender` varchar(5) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `Security_A` varchar(10) DEFAULT NULL,
  `security_q` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminstrator`
--

INSERT INTO `adminstrator` (`admin_id`, `username`, `full_name`, `password`, `gender`, `email`, `mobile`, `Security_A`, `security_q`) VALUES
(3, 'admin', 'admin', 'admin', 'Male', 'yugiughkj', '3456789876', '123456', 'First Phone Number'),
(4, 'admin1', 'jhdajkhdj', 'admin1', '', '', '', '1234', 'First Phone Number');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `CON_ID` varchar(1) DEFAULT NULL,
  `C_name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`CON_ID`, `C_name`) VALUES
('1', 'Bangladesh'),
('2', 'Germany'),
('3', 'Finland');

-- --------------------------------------------------------

--
-- Table structure for table `course_teacher`
--

CREATE TABLE `course_teacher` (
  `ct_id` int(11) NOT NULL,
  `username` varchar(10) DEFAULT NULL,
  `full_name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `gender` varchar(5) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `Subject` varchar(10) DEFAULT NULL,
  `Security_A` varchar(20) DEFAULT NULL,
  `security_q` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_teacher`
--

INSERT INTO `course_teacher` (`ct_id`, `username`, `full_name`, `password`, `gender`, `email`, `mobile`, `Subject`, `Security_A`, `security_q`) VALUES
(5, 'teacher', 'teacher', 'teacher', 'Male', 'teacher@gmail.com', '098899889', 'Physics', '0989898877', 'First Phone Number'),
(6, 'bangla', 'bangla teacher', 'bangla', 'Male', 'bangal@gmail.com', '493482782', 'Bangla', '932278822', 'First Phone Number'),
(7, 'physics', 'physics teacher', 'physics', 'Male', 'hjjshsjjs@gmail.com', '3478378378', 'Physics', 'eu89783389', 'First Phone Number'),
(8, 'english', 'english', 'english', 'Male', 'iwswh@emnd.com', '5875783578', 'English', '887437848794', 'First Phone Number');

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

CREATE TABLE `employe` (
  `emp_id` int(5) NOT NULL,
  `username` varchar(20) DEFAULT '',
  `full_name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `gender` varchar(7) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `Sucurity_A` varchar(20) DEFAULT NULL,
  `sucurity_q` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employe`
--

INSERT INTO `employe` (`emp_id`, `username`, `full_name`, `password`, `gender`, `email`, `mobile`, `Sucurity_A`, `sucurity_q`) VALUES
(2, 'admin', 'admin admin', 'admin', 'Male', 'dmin@gmail.com', '0178888888', NULL, NULL),
(17, 'mohapurosh', 'Rabiul Tanvir', 'mohapurosh', 'Male', 'pathchari005@gmail.c', '016772632626', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `Student_Id` int(5) NOT NULL,
  `Class` int(2) NOT NULL,
  `Semester` int(1) NOT NULL,
  `Bangla` varchar(3) DEFAULT NULL,
  `English` varchar(3) DEFAULT NULL,
  `Mathematics` varchar(3) DEFAULT NULL,
  `Physics` varchar(3) DEFAULT NULL,
  `Chemistry` varchar(3) DEFAULT NULL,
  `Biology` varchar(3) DEFAULT NULL,
  `ICT` varchar(3) DEFAULT NULL,
  `Higher_mathematics` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`Student_Id`, `Class`, `Semester`, `Bangla`, `English`, `Mathematics`, `Physics`, `Chemistry`, `Biology`, `ICT`, `Higher_mathematics`) VALUES
(1, 10, 1, '80', '90', NULL, '56', NULL, NULL, NULL, NULL),
(1, 10, 2, NULL, NULL, NULL, '80', NULL, NULL, NULL, NULL),
(1, 10, 3, NULL, NULL, NULL, '70', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_bio`
--

CREATE TABLE `student_bio` (
  `Student_Id` int(5) NOT NULL,
  `Class` int(2) NOT NULL,
  `Frist_Name` varchar(10) DEFAULT NULL,
  `Lasat_Name` varchar(10) DEFAULT NULL,
  `Fathers_Name` varchar(20) DEFAULT NULL,
  `Motherst_Name` varchar(10) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `DOB` varchar(10) DEFAULT NULL,
  `DOR` varchar(10) DEFAULT NULL,
  `Adress` varchar(30) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `Division` varchar(10) DEFAULT NULL,
  `city` varchar(10) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `Academic_year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_bio`
--

INSERT INTO `student_bio` (`Student_Id`, `Class`, `Frist_Name`, `Lasat_Name`, `Fathers_Name`, `Motherst_Name`, `Email`, `Phone`, `DOB`, `DOR`, `Adress`, `Gender`, `Division`, `city`, `country`, `Academic_year`) VALUES
(1, 3, 'a', 'shbchas', 'x', 'hsbadjas', 'x', '12763812', '2/23/2019', '2/23/2019', 'x', 'Male', 'x', 'x', 'x', 2019),
(90, 7, 'Rabiul', 'Tanvir', 'Md Tazul Islam', 'Mst Taslim', 'pathchari005@gmail.com', '01785722299', '2/15/2019', '2/15/2019', 'mirpur-1,Dhaka', 'Male', 'Dhaka', 'Dhaka', 'Bangladesh', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accademicfees`
--
ALTER TABLE `accademicfees`
  ADD PRIMARY KEY (`Student_Id`,`Class`);

--
-- Indexes for table `accountent`
--
ALTER TABLE `accountent`
  ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`inbuildsecurity`);

--
-- Indexes for table `adminstrator`
--
ALTER TABLE `adminstrator`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_teacher`
--
ALTER TABLE `course_teacher`
  ADD PRIMARY KEY (`ct_id`);

--
-- Indexes for table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`Student_Id`,`Class`,`Semester`);

--
-- Indexes for table `student_bio`
--
ALTER TABLE `student_bio`
  ADD PRIMARY KEY (`Student_Id`,`Class`,`Academic_year`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountent`
--
ALTER TABLE `accountent`
  MODIFY `ac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `adminstrator`
--
ALTER TABLE `adminstrator`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_teacher`
--
ALTER TABLE `course_teacher`
  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employe`
--
ALTER TABLE `employe`
  MODIFY `emp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
